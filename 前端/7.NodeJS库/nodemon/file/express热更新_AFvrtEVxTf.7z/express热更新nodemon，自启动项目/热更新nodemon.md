# express热更新nodemon，自启动项目

## 目的

+ 每次修改文件，我们都需要重启服务器 `npm start`，很麻烦，所以使用引入 `nodemon` 插件，解决这个问题，实现保存文件，即自启动刷新项目

## 使用

+ 安装：
+ `--save-dev`：安装到本项目的dev开发环境依赖下
+ `-g`：全局安装nodemon

  ```js
  npm install nodemon -g --save-dev
  ```

+ 新增 `nodemon.json` 文件
+ ![新增文件](新增文件.jpg)

+ 执行

  ```shell
  nodemon app
  ```

  ![执行](执行.jpg)