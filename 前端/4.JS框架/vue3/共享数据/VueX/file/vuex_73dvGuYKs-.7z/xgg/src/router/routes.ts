export default [
  {
    path: "/",
    component: () => import('./../views/Home.vue')
  },
  {
    path: "/login",
    component: import("./../views/Login.vue") // 异步加载
  }
]
