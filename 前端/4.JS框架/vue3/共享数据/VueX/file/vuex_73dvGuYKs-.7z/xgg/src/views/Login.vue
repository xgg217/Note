<template>
  <form @submit.prevent="handleSubmit">
    <div>
      <label>账号</label>
      <input type="text" v-model="loginId" placeholder="请输入账号">
    </div>
    <div>
      <label>密码</label>
      <input type="text" v-model="loginPwd" placeholder="请输入密码">
    </div>
    <div>
      <label></label>
      <button :disabled="loading">{{ loading ? '登录中' : '登录' }}</button>
    </div>
  </form>
</template>

<script setup lang="ts">

import { ref, computed } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'
const loginId = ref('');
const loginPwd = ref('');

const store = useStore();
const router = useRouter();

const loading = computed(() => {
  return store.state.loginUser.loading;
})

/**
 * 登录
 */
const handleSubmit = async () => {
  const user = await store.dispatch('loginUser/login', { loginId: loginId.value, loginPwd: loginPwd.value })
  if(user) {
    // 登录成功
    router.push('/'); // 跳转
    return;
  }
  alert('密码或账号输入错误')
}



</script>

<style>

</style>