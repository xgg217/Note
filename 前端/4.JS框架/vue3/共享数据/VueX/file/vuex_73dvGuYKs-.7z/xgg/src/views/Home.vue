<template>
  <div>home</div>
</template>

<script setup lang="ts">

</script>

<style>

</style>