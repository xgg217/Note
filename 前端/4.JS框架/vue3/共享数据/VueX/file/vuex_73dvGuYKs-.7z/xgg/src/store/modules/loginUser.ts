import {apiLogin, apiLoginOut, apiWhoAmI} from './../../api/user'

const state = () => ({
  user:null,
  loading: false
});

const mutations = {
  setUser(state, pauload) {
    state.user = pauload
  },

  setLoading(state, pauload) {
    state.loading = pauload
  }
}

const actions = {
  // 登录
  async login({ commit }, { loginId, loginPwd }) {
    commit('setLoading', true)
    const user = await apiLogin(loginId, loginPwd);
    commit('setUser', user);
    commit('setLoading', false);
    return user
  },

  // 退出
  async LoginOut({ commit }) {
    commit('setLoading', true);
    await apiLoginOut();
    commit('setUser', null);
    commit('setLoading', false);
  },

  // 获取用户信息
  async whoAmI({ commit }) {
    commit('setLoading', true);
    console.log('获取用户信息');
    const user = await apiWhoAmI();
    commit('setUser', user);
    commit('setLoading', false);
  }
}

export default {
  namespaced: true, // 开启命名空间
  state,
  mutations,
  actions
}
