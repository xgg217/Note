interface IUser {
  loginId:string
  name:string
}

/**
 * 延迟函数
 * @param duration 
 * @returns 
 */
function delay(duration = 1000) {
  return new Promise(res => {
    setTimeout(() => {
      res(null);
    }, duration)
  })
}

/**
 * 登录
 * @param ids 账号
 * @param pwd 密码
 * @returns 
 */
async function apiLogin(ids:string, pwd:string):Promise<IUser|null> {
  await delay();
  if((ids === 'admin') && (pwd === '123456')) {
    const user:IUser = {
      loginId: ids,
      name: '管理员'
    };
    localStorage.setItem('user', JSON.stringify(user))
    return user
  }
  return null;
}

/**
 * 退出
 */
async function apiLoginOut() {
  await delay();
  localStorage.removeItem('user')
}

/**
 * 获取当前用户信息
 * @returns 
 */
async function apiWhoAmI():Promise<IUser|null> {
  await delay();
  const user = localStorage.getItem('user');
  if(user) {
    return JSON.parse(user);
  }
  return null;
}

export {
  apiLogin,
  apiLoginOut,
  apiWhoAmI
}

