<template>
  <router-link to="/">home</router-link>
  <span v-if="loading">登录中</span>
  <template v-else-if="user">
    <span>{{ user.name }}</span>
    <span @click="handleTui">退出</span>
  </template>
  <router-link v-else to="/login">登录</router-link>
  <router-view></router-view>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'

const store = useStore();
const router = useRouter();

// 登录状态控制
(() => {
  store.dispatch('loginUser/whoAmI')
})()

/**
 * 登录相关
 */
const { loading, user, handleTui } = (() => {

  // 获取登录状态
  const loading = computed(() => {
    return store.state.loginUser.loading
  })

  // 获取用户信息
  const user = computed(() => {
    console.log(store.state.loginUser.user);
    return store.state.loginUser.user
  })

  // 退出
  const handleTui = async () => {
    await store.dispatch('loginUser/LoginOut')
    router.replace('/login')
  }


  return {
    loading,
    user,
    handleTui
  }

})()



</script>
