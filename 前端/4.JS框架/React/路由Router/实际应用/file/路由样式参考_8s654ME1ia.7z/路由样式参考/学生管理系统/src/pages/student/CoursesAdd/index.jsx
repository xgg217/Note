import React from 'react'

export default function index() {
  return (
    <div>
      课程添加
    </div>
  )
}
