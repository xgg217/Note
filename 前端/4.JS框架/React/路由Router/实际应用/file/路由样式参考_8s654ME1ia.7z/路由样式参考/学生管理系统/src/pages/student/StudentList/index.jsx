import React from 'react'

export default function index() {
  return (
    <div>
      学生列表
    </div>
  )
}
