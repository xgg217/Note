import React from 'react'
import { Switch, Route } from 'react-router-dom'

import Layout from './../../components/Layout/index'
import Header from './../../components/Header/index';
import Menu from './../../components/Menu/index'
import Welcom from './../../components/Welcom/index'
import StudentList from './../student/StudentList/index'
import StudentAdd from './../student/StudentAdd/index'
import CoursesList from './../student/CoursesList/index'
import CoursesAdd from './../student/CoursesAdd/index'

export default function index() {
  return (
    <div>
      <Layout
        header={ <Header /> }
        aside={ <Menu/> }
      >
        <Switch>
          <Route path="/" exact component={ Welcom }></Route>
          <Route path="/students" exact component={ StudentList }></Route>
          <Route path="/students/add" exact component={ StudentAdd }></Route>
          <Route path="/courses" exact component={ CoursesList }></Route>
          <Route path="/courses/add" exact component={ CoursesAdd }></Route>
        </Switch>
        
      </Layout>
    </div>
  )
}
