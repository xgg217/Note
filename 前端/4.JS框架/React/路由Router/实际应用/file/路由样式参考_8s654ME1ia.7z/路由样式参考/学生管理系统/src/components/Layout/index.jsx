import React from 'react'
import './index.css';
import PropTypes from 'prop-types';

export default function index(props) {
  return (
    <div className="warpper">
      <header className="header">
        { props.header }
      </header>
      <section className="middle">
        <aside>
          { props.aside }
        </aside>
        <div className="rig">
          { props.children }
        </div>
      </section>
    </div>
  )
}

index.propTypes = {
  header: PropTypes.element,
  aside: PropTypes.element,
  rig: PropTypes.element,

}


