import React from 'react'
import { NavLink } from 'react-router-dom';
import './index.css'

export default function index() {
  return (
    <ul className="menu">
      <li>
        <NavLink to="/students" activeClassName="selected">学生列表</NavLink>
      </li>
      <li>
        <NavLink to="/students/add" activeClassName="selected">添加学生</NavLink>
      </li>
      <li>
        <NavLink to="/courses" activeClassName="selected">课程列表</NavLink>
      </li>
      <li>
        <NavLink to="/courses/add" activeClassName="selected">添加课程</NavLink>
      </li>
    </ul>
  )
}
