import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'

import './App.css';

import Login from "./pages/Login/index"
import Admin from "./pages/Admin/index"

function App() {
  return (
    // <div className="App">
    //   <Layout className="layout" ></Layout>
    // </div>
    <Router>
      <Switch>
        <Route path="/login" exact component={ Login }></Route>
        <Route path="/" component={ Admin }></Route>
      </Switch>
    </Router>
  );
}

export default App;
