import React from 'react'

import './index.css'

export default function index() {
  return (
    <div className="header-top">
      <h2>学生管理系统</h2>
      <div>
        <span>用户名</span>
        <p>退出</p>
      </div>
    </div>
  )
}
