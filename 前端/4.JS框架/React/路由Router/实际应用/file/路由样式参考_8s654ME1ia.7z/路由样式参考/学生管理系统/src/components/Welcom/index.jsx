import React from 'react'

export default function index() {
  return (
    <div>
      欢迎使用学生管理系统--小刚刚
    </div>
  )
}
